/**
 ****************************************************************************************************
 * @file        main.c
 * @brief       任务1：定时器计数方式控制 LED 以 2s 周期亮-灭（HAL 库版）
 * @note
 *              平台：正点原子 MiniSTM32（STM32F103RCT6），HAL 库
 *              定时器：TIM2（属于题目要求的 TIM2~TIM5），定时 1s 进一次更新中断
 *              中断里翻转 LED 引脚电平 → LED 亮 1s、灭 1s，亮灭周期 = 2s
 *
 *              LED 接线（高电平点亮）：
 *              PA0（TIM2_CH1 复用引脚）→ 330Ω 限流电阻 → LED 阳极；LED 阴极 → GND
 *              同时板载 LED1（PD2）也会同步翻转，不接线也能看到效果
 *
 *              定时 1s 计算：72MHz / (7200) / (10000) = 1Hz
 *              gtim_timx_int_init(arr=10000-1, psc=7200-1)
 ****************************************************************************************************
 */

#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"
#include "./BSP/TIMER/gtim.h"

/**
 * @brief       实验 LED 引脚初始化：PA0（TIM2_CH1 复用引脚）推挽输出
 * @note        任务1 用定时器中断翻转电平，不占用引脚复用输出功能，
 *              PA0 按普通推挽输出配置即可；若后续改 PWM 需换成 GPIO_MODE_AF_PP
 */
void led_pa0_init(void)
{
    GPIO_InitTypeDef gpio_init_struct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();                           /* 使能 GPIOA 时钟 */

    gpio_init_struct.Pin = GPIO_PIN_0;                      /* PA0 */
    gpio_init_struct.Mode = GPIO_MODE_OUTPUT_PP;            /* 推挽输出 */
    gpio_init_struct.Pull = GPIO_NOPULL;                    /* 不上下拉 */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;          /* 高速 */
    HAL_GPIO_Init(GPIOA, &gpio_init_struct);

    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);   /* 初始熄灭 */
}

int main(void)
{
    uint8_t i;

    HAL_Init();                                             /* 初始化 HAL 库 */
    sys_stm32_clock_init(RCC_PLL_MUL9);                     /* 8MHz * 9 = 72MHz */
    delay_init(72);                                         /* 延时初始化（72MHz） */
    usart_init(115200);                                     /* 串口初始化（调试用） */

    led_init();                                             /* 板载 LED0(PA8)/LED1(PD2) 初始化 */
    led_pa0_init();                                         /* 实验 LED：PA0 初始化 */

    /* 启动特征：板载 LED1 快闪 3 次，用于确认复位后跑的是本程序 */
    for (i = 0; i < 3; i++)
    {
        LED1(0);                                            /* LED1 点亮（低电平有效） */
        delay_ms(150);
        LED1(1);                                            /* LED1 熄灭 */
        delay_ms(150);
    }

    gtim_timx_int_init(10000 - 1, 7200 - 1);                /* TIM2 定时 1s，开更新中断 */

    while (1)
    {
        /* 亮灭翻转全部由 TIM2 更新中断完成，主循环空转 */
    }
}
