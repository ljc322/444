/**
 ****************************************************************************************************
 * @file        main.c
 * @brief       任务2：定时器 PWM 模式驱动 LED 呼吸灯（渐亮渐灭，周期约 1s，可调至 2s）
 * @note
 *              平台：正点原子 MiniSTM32（STM32F103RCT6），HAL 库
 *              通道：TIM2_CH1 → PA0（gtim.h 已按题目配置，无需改动）
 *              PWM ：PSC=71、ARR=999 → 计数频率 1MHz、PWM 频率 1kHz
 *              呼吸 ：CCR 从 0→999（占空比 0%→100%）渐亮，999→0 渐灭，
 *                     步进 2、延时 1ms → 单程约 500ms，完整呼吸周期约 1s
 *
 *              LED 接线（与任务1 相同）：PA0 → 330Ω 限流电阻 → LED 阳极；LED 阴极 → GND
 *
 *              周期调节：步进 1 + 延时 1ms → 周期约 2s；步进 2 + 延时 2ms → 周期约 2s
 *
 *              Keil 虚拟示波器：Options→Debug 选 Use Simulator → 进仿真 →
 *              View→Analysis Windows→Logic Analyzer → Setup 添加：
 *                  PORT A.0（Display Type: Bit）看 PWM 方波；
 *                  TIM2->CCR1（Display Type: Analog）看占空比渐变
 ****************************************************************************************************
 */

#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"
#include "./BSP/TIMER/gtim.h"

extern TIM_HandleTypeDef g_timx_pwm_chy_handle;     /* gtim.c 中的 TIM2 PWM 句柄 */

int main(void)
{
    uint16_t ledrpwmval = 0;
    uint8_t dir = 1;

    HAL_Init();                             /* 初始化 HAL 库 */
    sys_stm32_clock_init(RCC_PLL_MUL9);     /* 8MHz * 9 = 72MHz */
    delay_init(72);                         /* 延时初始化（72MHz） */
    usart_init(115200);                     /* 串口初始化（调试用） */

    /* TIM2_CH1(PA0) PWM 输出：1MHz 计数频率 → 1kHz PWM，初始占空比 50% */
    gtim_timx_pwm_chy_init(1000 - 1, 72 - 1);

    while (1)
    {
        delay_ms(1);

        if (dir) ledrpwmval += 2;           /* 渐亮：占空比上升 */
        else     ledrpwmval -= 2;           /* 渐灭：占空比下降 */

        if (ledrpwmval > 999) dir = 0;      /* 到 100%（CCR=999）后转向渐灭 */
        if (ledrpwmval == 0)  dir = 1;      /* 到 0% 后转向渐亮 */

        /* 更新比较寄存器 → 改变 PWM 占空比 */
        __HAL_TIM_SET_COMPARE(&g_timx_pwm_chy_handle, GTIM_TIMX_PWM_CHY, ledrpwmval);
    }
}
